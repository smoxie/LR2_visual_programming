﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp12
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            StartRotationAnimation();
            StartTranslationAnimation();
        }

        private void StartRotationAnimation()
        {  
            GeometryModel3D sailModel = (GeometryModel3D)FindName("sailModel");
            AxisAngleRotation3D rotation = new AxisAngleRotation3D(new Vector3D(0, 1, 0), 0);
            RotateTransform3D rotateTransform = new RotateTransform3D(rotation);
            sailModel.Transform = rotateTransform;
            DoubleAnimation rotationAnimation = new DoubleAnimation();
            rotationAnimation.From = 0;
            rotationAnimation.To = 360;
            rotationAnimation.Duration = TimeSpan.FromSeconds(5);
            rotationAnimation.RepeatBehavior = RepeatBehavior.Forever;
            rotation.BeginAnimation(AxisAngleRotation3D.AngleProperty, rotationAnimation);
        }

        private void StartTranslationAnimation()
        {
            ModelVisual3D sailboatModel = (ModelVisual3D)FindName("sailboatModel");
            DoubleAnimation translateAnimation = new DoubleAnimation();
            translateAnimation.From = -1; 
            translateAnimation.To = 1; 
            translateAnimation.Duration = TimeSpan.FromSeconds(5);
            translateAnimation.AutoReverse = true;
            translateAnimation.RepeatBehavior = RepeatBehavior.Forever;
            TranslateTransform3D translateTransform = new TranslateTransform3D();
            sailboatModel.Transform = translateTransform;
            translateTransform.BeginAnimation(TranslateTransform3D.OffsetXProperty, translateAnimation);
        }
    }
}